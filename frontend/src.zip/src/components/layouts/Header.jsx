import React from 'react';
import { useTranslation } from 'react-i18next';
import ThemeToggle from '../common/ThemeToggle.jsx'; // Import the new component

function Header() {
  const { t } = useTranslation();

  return (
    <header className="app-header">
      <h1 className="logo">Personal Modified Internship Organizer</h1>
      <ThemeToggle /> {/* Add the toggle button here */}
    </header>
  );
}

export default Header;