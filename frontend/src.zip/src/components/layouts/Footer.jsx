import React from 'react';
import { useTranslation } from 'react-i18next';

function Footer() {
  const { t } = useTranslation();

  return (
    <footer className="app-footer">
      <p>&copy; 2025 {t('app_name')} Prototype made for SIH 

      </p>
    </footer>
  );
}

export default Footer;